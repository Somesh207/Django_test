from django.shortcuts import render,redirect,get_object_or_404
from .models import Office

# Create your views here.

def create_office(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        location = request.POST.get('location')
        employees_count = request.POST.get('employees_count')

        Office.objects.create(name=name,location=location,employees_count=employees_count)
        return redirect('office_list')
    return render(request,'createOffice.html')    


def office_list(request):
    offices = Office.objects.all()
    return render(request,'officeList.html',{'offices':offices})


def get_office(request,id):
    office = get_object_or_404(Office,id=id)
    return render(request,'getOffice.html',{'office':office})

def delete_office(request,id):
    office = get_object_or_404(Office,id=id)
    office.delete()
    return redirect('office_list')

def update_office(request,id):
    office = get_object_or_404(Office,id=id)
    if request.method == 'POST':
        name = request.POST.get('name')
        location = request.POST.get('location')
        employees_count = request.POST.get('employees_count')

        office.name = name
        office.location = location
        office.employees_count = employees_count
        office.save()
        return redirect('office_list')
    return render(request,'updateOffice.html',{'office':office})  