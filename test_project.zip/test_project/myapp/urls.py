from django.urls import path
from . import views

urlpatterns = [
    path('create/',views.create_office,name='create_office'),
    path('list/',views.office_list,name='office_list'),
    path('get/<int:id>',views.get_office,name='get_office'),
    path('delete/<int:id>',views.delete_office,name='delete_office'),
    path('update/<int:id>',views.update_office,name='update_office'),
]
